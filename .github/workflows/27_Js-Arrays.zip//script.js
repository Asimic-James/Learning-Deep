// Created Using Easy HTML v1.3.1
// https://play.google.com/store/apps/details?id=ak.andro.easyhtml

// Arrays
var cities = ["Atlanta","New York","Lagos","Port Harcourt","Umuahia","Abuja"];
alert ("Welcome to " + cities[4]);
var mixedArray =[1,"Simic","Are You Sure?","True","False"];
alert ("I am honest " + mixedArray[2]);
// Adding and Removing Elements
var schools = [];
var schoolToCheck = prompt("Input Your School");
schools[0] = "Umudike";
schools[1] = "Uniport";
schools[2] = "Unilag";
schools[3] = "Absu";
schools[4] = "Unical";
schools.pop ();
schools.push ("Uwanna", "Ebsu");    
if (schoolToCheck===schools[5]){
alert ("Welcome to " + schools[5]);
  }
else{
 alert ("Sorry You Inputed The Wrong School!");}
// Removing, Inserting and Extracting Elements
schools.shift();
alert("Welcome to " + schools[0]);
schools.unshift("UNN","Uniben");
alert("You were admitted here: " + schools[1]);
schools.splice("Harvard","Cambridge","Oxford","Michigan");
alert ("You won a Scholarship to study at: " + schools[0]);
//For Loop Statements
var cityToCheck =prompt("Input Your City");
 cityToCheck = cityToCheck.toLowerCase();
var cleanestCities= ["new york","washington","lagos","dubai"];
var matchFound = false;
for (var i = 0; i <= 4; i++){
if (cityToCheck === cleanestCities[i]){
matchFound = true;
  alert("It's one of the cleanest cities");
  break;
}
  }
if (matchFound === false) {
alert("It's not on the list");
 }
//For Loop Nested
function checkNames(){
var firstNames=["Asimic","Jennifer","Prince","Emmanuel","Victor"];
var lastNames=["James","Hrty","Johnson","Eze","Odoh"];
var fullNames =[];
for (var i = 0; i < firstNames.length; i++){
  for (var j = 0; j < lastNames.length; j++){
fullNames.push (firstNames[i] + lastNames[j]);
alert (fullNames);  
  }

}
  }
checkNames();
function ShowRound(scoreAvg)
{
  var num = Math.round(76.5);
  alert(num);
  }
function ShowFloor(scoreAvg)
{
  var num = Math.ceil(.999999);
  alert (num);
  }
ShowRound(76.5);
ShowFloor(.999999);
 function tellTime() {
var now = new Date();
var theHr = now.getHours();
var theMin = now.getMinutes();
alert("Current time: "+ theHr + ":" + theMin  + " On This Day " + now);
}
tellTime();

